/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { ProfileForm } from './pages/ProfileForm';
import { ProfileList } from './pages/ProfileList';
import { ProfileDetail } from './pages/ProfileDetail';
import { Settings } from './pages/Settings';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="create" element={<ProfileForm />} />
          <Route path="edit/:id" element={<ProfileForm />} />
          <Route path="profiles" element={<ProfileList />} />
          <Route path="profiles/:id" element={<ProfileDetail />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </Router>
  );
}
