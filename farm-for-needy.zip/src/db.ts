export interface FormQuestion {
  id: string;
  text: string;
  type: 'select' | 'boolean';
  options?: { label: string; score: number }[]; // For 'select'
  scoreIfTrue?: number; // For 'boolean' ('Yes' gets this score, 'No' gets 0)
  hasConditionalField?: boolean;
  conditionalTrigger?: string; // e.g. "Yes"
  conditionalLabel?: string;
  conditionalType?: 'text' | 'number';
}

export interface Profile {
  id?: string;
  // Basic Info (Fixed)
  applicationNumber: string;
  district: string;
  name: string;
  fatherName: string;
  cnic: string;
  address: string;
  phoneNumber: string;
  professionOfOthers?: string; // Kept as basic info since it wasn't scored
  
  // Dynamic Answers
  answers: Record<string, any>;
  conditionalAnswers: Record<string, any>;
  
  // Calculated
  score: number;
  scoreBreakdown: Record<string, number>;
  
  createdAt: number;
  updatedAt: number;
}

export interface Settings {
  id?: string;
  questions: FormQuestion[];
}

export const defaultQuestions: FormQuestion[] = [
  {
    id: 'householdSize',
    text: 'Total people living in the home',
    type: 'select',
    options: [
      { label: '1-3', score: 2 },
      { label: '4-6', score: 5 },
      { label: '7+', score: 10 }
    ]
  },
  {
    id: 'profession',
    text: 'Profession',
    type: 'select',
    options: [
      { label: 'Unemployed', score: 20 },
      { label: 'Daily wage', score: 15 },
      { label: 'Low salary job', score: 8 },
      { label: 'Stable job', score: 0 }
    ]
  },
  {
    id: 'monthlyIncome',
    text: 'Monthly Income',
    type: 'select',
    options: [
      { label: '0-20k', score: 20 },
      { label: '20k-50k', score: 10 },
      { label: '50k+', score: 0 }
    ]
  },
  {
    id: 'totalHouseholdIncome',
    text: 'Total Household Income',
    type: 'select',
    options: [
      { label: 'Low', score: 10 },
      { label: 'Medium', score: 0 },
      { label: 'High', score: 0 }
    ]
  },
  {
    id: 'numberOfMobilePhones',
    text: 'Number of mobile phones in the home',
    type: 'select',
    options: [
      { label: '0-1', score: 5 },
      { label: '2-3', score: 2 },
      { label: '4+', score: 0 }
    ]
  },
  {
    id: 'governmentSupport',
    text: 'Government support',
    type: 'boolean',
    scoreIfTrue: -10,
    hasConditionalField: true,
    conditionalTrigger: 'Yes',
    conditionalLabel: 'Amount received',
    conditionalType: 'number'
  },
  {
    id: 'externalSupport',
    text: 'Support from a person or industry',
    type: 'boolean',
    scoreIfTrue: -5,
    hasConditionalField: true,
    conditionalTrigger: 'Yes',
    conditionalLabel: 'Amount received',
    conditionalType: 'number'
  },
  {
    id: 'debtForBasicNeeds',
    text: 'Debt taken for basic needs',
    type: 'boolean',
    scoreIfTrue: 10,
    hasConditionalField: true,
    conditionalTrigger: 'Yes',
    conditionalLabel: 'Debt amount',
    conditionalType: 'number'
  },
  {
    id: 'disabilityInHousehold',
    text: 'Any disability in the house',
    type: 'boolean',
    scoreIfTrue: 15,
    hasConditionalField: true,
    conditionalTrigger: 'Yes',
    conditionalLabel: 'Type of disability',
    conditionalType: 'text'
  },
  {
    id: 'houseStatus',
    text: 'House status',
    type: 'select',
    options: [
      { label: 'Owned', score: 0 },
      { label: 'Rented', score: 8 },
      { label: 'Temporary', score: 15 },
      { label: 'Shelter / informal housing', score: 20 }
    ]
  },
  {
    id: 'schoolFees',
    text: 'School fees for children (High cost relative to income)',
    type: 'boolean',
    scoreIfTrue: 10
  }
];
