import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Profile } from '../db';
import { calculateScore } from '../scoring';
import { useProfile, useSettings, addProfile, updateProfile } from '../hooks/useFirebase';
import { motion } from 'motion/react';
import { Save, ArrowLeft } from 'lucide-react';

export function ProfileForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = !!id;

  const { register, handleSubmit, watch, reset, formState: { errors } } = useForm<Profile>();
  const [isSaving, setIsSaving] = useState(false);

  const settings = useSettings();
  const profile = useProfile(id);

  useEffect(() => {
    if (isEditing) {
      if (profile === null) {
        navigate('/profiles');
      } else if (profile) {
        reset(profile);
      }
    }
  }, [profile, isEditing, reset, navigate]);

  const watchAnswers = watch('answers') || {};

  const onSubmit = async (data: Profile) => {
    if (!settings) return;
    setIsSaving(true);

    try {
      const { score, breakdown } = calculateScore(data, settings);
      
      const profileToSave = {
        ...data,
        score,
        scoreBreakdown: breakdown,
        updatedAt: Date.now(),
      };

      if (isEditing && id) {
        await updateProfile(id, profileToSave);
      } else {
        profileToSave.createdAt = Date.now();
        await addProfile(profileToSave as Omit<Profile, 'id'>);
      }

      navigate('/profiles');
    } catch (error) {
      console.error('Failed to save profile:', error);
      alert('Failed to save profile. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!settings) return <div className="p-8 text-center">Loading settings...</div>;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto"
    >
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 rounded-full hover:bg-slate-200 transition-colors text-slate-600"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-slate-900">
            {isEditing ? 'Edit Profile' : 'Create New Profile'}
          </h1>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8 bg-white p-6 sm:p-8 rounded-2xl shadow-sm border border-slate-200">
        
        {/* Section 1: Basic Information */}
        <section className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-800">Section 1: Basic Information</h2>
            <p className="text-sm text-slate-500">This information is stored but does not affect the need score.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Application Number</label>
              <input 
                {...register('applicationNumber', { required: 'Required' })} 
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                placeholder="Unique ID"
              />
              {errors.applicationNumber && <p className="text-red-500 text-xs mt-1">{errors.applicationNumber.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">District</label>
              <input 
                {...register('district', { required: 'Required' })} 
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              />
              {errors.district && <p className="text-red-500 text-xs mt-1">{errors.district.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
              <input 
                {...register('name', { required: 'Required' })} 
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              />
              {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Father's Name</label>
              <input 
                {...register('fatherName', { required: 'Required' })} 
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              />
              {errors.fatherName && <p className="text-red-500 text-xs mt-1">{errors.fatherName.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">CNIC</label>
              <input 
                {...register('cnic', { required: 'Required' })} 
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                placeholder="00000-0000000-0"
              />
              {errors.cnic && <p className="text-red-500 text-xs mt-1">{errors.cnic.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
              <input 
                {...register('phoneNumber', { required: 'Required' })} 
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              />
              {errors.phoneNumber && <p className="text-red-500 text-xs mt-1">{errors.phoneNumber.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Profession of other people in the home</label>
              <input 
                {...register('professionOfOthers')} 
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                placeholder="Optional"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
              <textarea 
                {...register('address', { required: 'Required' })} 
                rows={3}
                className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              />
              {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address.message}</p>}
            </div>
          </div>
        </section>

        {/* Section 2: Scored Questions (Dynamic) */}
        <section className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-800">Section 2: Scored Questions</h2>
            <p className="text-sm text-slate-500">These fields contribute to the Need Score.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {settings.questions?.map((q) => {
              const currentAnswer = watchAnswers[q.id];
              const showConditional = q.hasConditionalField && currentAnswer === q.conditionalTrigger;

              return (
                <div key={q.id} className={showConditional ? "space-y-4 p-4 bg-slate-50 rounded-xl border border-slate-100" : ""}>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">{q.text}</label>
                    <select 
                      {...register(`answers.${q.id}`, { required: 'Required' })}
                      className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all bg-white"
                    >
                      <option value="">Select...</option>
                      {q.type === 'boolean' ? (
                        <>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </>
                      ) : (
                        q.options?.map((opt, i) => (
                          <option key={i} value={opt.label}>{opt.label}</option>
                        ))
                      )}
                    </select>
                    {errors.answers?.[q.id] && <p className="text-red-500 text-xs mt-1">{errors.answers[q.id]?.message as string}</p>}
                  </div>
                  
                  {showConditional && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                      <label className="block text-sm font-medium text-slate-700 mb-1">{q.conditionalLabel}</label>
                      <input 
                        type={q.conditionalType === 'number' ? 'number' : 'text'}
                        {...register(`conditionalAnswers.${q.id}`, { required: 'Required' })} 
                        className="w-full px-4 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                      />
                      {errors.conditionalAnswers?.[q.id] && <p className="text-red-500 text-xs mt-1">{errors.conditionalAnswers[q.id]?.message as string}</p>}
                    </motion.div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        <div className="pt-6 border-t border-slate-200 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 disabled:opacity-50 transition-colors"
          >
            <Save className="w-5 h-5 mr-2" />
            {isSaving ? 'Saving...' : 'Save Profile'}
          </button>
        </div>

      </form>
    </motion.div>
  );
}
