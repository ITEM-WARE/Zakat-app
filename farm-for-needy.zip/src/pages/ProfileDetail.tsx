import { useParams, Link, useNavigate } from 'react-router-dom';
import { useProfile, useSettings, deleteProfile } from '../hooks/useFirebase';
import { motion } from 'motion/react';
import { ArrowLeft, Edit, Trash2, User, FileText, Activity } from 'lucide-react';

export function ProfileDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const profile = useProfile(id);
  const settings = useSettings();

  if (profile === undefined || settings === undefined) return <div className="p-8 text-center">Loading...</div>;
  if (profile === null) return <div className="p-8 text-center">Profile not found.</div>;

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this profile?')) {
      await deleteProfile(id!);
      navigate('/profiles');
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-8"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 rounded-full hover:bg-slate-200 transition-colors text-slate-600"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-slate-900">Profile Details</h1>
        </div>
        <div className="flex space-x-3">
          <Link 
            to={`/edit/${profile.id}`}
            className="inline-flex items-center px-4 py-2 border border-slate-300 rounded-xl shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors"
          >
            <Edit className="w-4 h-4 mr-2" /> Edit
          </Link>
          <button 
            onClick={handleDelete}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors"
          >
            <Trash2 className="w-4 h-4 mr-2" /> Delete
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Details */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-5 border-b border-slate-200 bg-slate-50 flex items-center">
              <User className="w-5 h-5 text-slate-500 mr-2" />
              <h3 className="text-lg leading-6 font-medium text-slate-900">Basic Information</h3>
            </div>
            <div className="px-6 py-5">
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-6">
                <div className="sm:col-span-1">
                  <dt className="text-sm font-medium text-slate-500">Full name</dt>
                  <dd className="mt-1 text-sm text-slate-900 font-semibold">{profile.name}</dd>
                </div>
                <div className="sm:col-span-1">
                  <dt className="text-sm font-medium text-slate-500">Father's Name</dt>
                  <dd className="mt-1 text-sm text-slate-900">{profile.fatherName}</dd>
                </div>
                <div className="sm:col-span-1">
                  <dt className="text-sm font-medium text-slate-500">CNIC</dt>
                  <dd className="mt-1 text-sm text-slate-900">{profile.cnic}</dd>
                </div>
                <div className="sm:col-span-1">
                  <dt className="text-sm font-medium text-slate-500">Phone</dt>
                  <dd className="mt-1 text-sm text-slate-900">{profile.phoneNumber}</dd>
                </div>
                <div className="sm:col-span-1">
                  <dt className="text-sm font-medium text-slate-500">Application No.</dt>
                  <dd className="mt-1 text-sm text-slate-900">{profile.applicationNumber}</dd>
                </div>
                <div className="sm:col-span-1">
                  <dt className="text-sm font-medium text-slate-500">District</dt>
                  <dd className="mt-1 text-sm text-slate-900">{profile.district}</dd>
                </div>
                <div className="sm:col-span-2">
                  <dt className="text-sm font-medium text-slate-500">Address</dt>
                  <dd className="mt-1 text-sm text-slate-900">{profile.address}</dd>
                </div>
              </dl>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-5 border-b border-slate-200 bg-slate-50 flex items-center">
              <FileText className="w-5 h-5 text-slate-500 mr-2" />
              <h3 className="text-lg leading-6 font-medium text-slate-900">Questionnaire Responses</h3>
            </div>
            <div className="px-6 py-5">
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-6">
                {settings?.questions?.map((q) => {
                  const answer = profile.answers?.[q.id];
                  const conditionalAnswer = profile.conditionalAnswers?.[q.id];
                  
                  if (answer === undefined || answer === '') return null;

                  return (
                    <div key={q.id} className="sm:col-span-2">
                      <dt className="text-sm font-medium text-slate-500">{q.text}</dt>
                      <dd className="mt-1 text-sm text-slate-900">
                        {String(answer)}
                        {q.hasConditionalField && q.conditionalTrigger === String(answer) && conditionalAnswer && (
                          <span className="ml-2 text-slate-600 italic">
                            ({q.conditionalLabel}: {conditionalAnswer})
                          </span>
                        )}
                      </dd>
                    </div>
                  );
                })}
              </dl>
            </div>
          </div>

        </div>

        {/* Right Column: Score */}
        <div className="space-y-6">
          <div className="bg-emerald-600 rounded-2xl shadow-lg overflow-hidden text-white">
            <div className="px-6 py-8 text-center">
              <p className="text-emerald-100 text-sm font-medium uppercase tracking-wider mb-2">Total Need Score</p>
              <p className="text-6xl font-black">{profile.score}</p>
            </div>
            <div className="bg-emerald-700 px-6 py-4">
              <h4 className="text-sm font-semibold mb-3 text-emerald-100 border-b border-emerald-600 pb-2">Score Breakdown</h4>
              <ul className="space-y-2 text-sm">
                {Object.entries(profile.scoreBreakdown || {}).map(([key, value]) => (
                  <li key={key} className="flex justify-between">
                    <span className="text-emerald-100">{key}</span>
                    <span className="font-bold">{Number(value) > 0 ? `+${value}` : value}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <h4 className="text-sm font-medium text-slate-500 mb-4 uppercase tracking-wider">Record Metadata</h4>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Created</span>
                <span className="text-slate-900 font-medium">{new Date(profile.createdAt).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Last Modified</span>
                <span className="text-slate-900 font-medium">{new Date(profile.updatedAt).toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </motion.div>
  );
}
