import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useProfiles, deleteProfile, useSettings } from '../hooks/useFirebase';
import { motion } from 'motion/react';
import { Search, ArrowUpDown, Trash2, Edit, Eye, Download } from 'lucide-react';

type SortOption = 'score' | 'latest' | 'modified';

export function ProfileList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('score');

  const allProfiles = useProfiles();
  const settings = useSettings();

  const profiles = useMemo(() => {
    if (!allProfiles) return undefined;
    
    let filtered = allProfiles;
    if (searchTerm) {
      const lowerTerm = searchTerm.toLowerCase();
      filtered = allProfiles.filter(p => 
        p.name.toLowerCase().includes(lowerTerm) || 
        p.cnic.includes(searchTerm) ||
        p.applicationNumber.toLowerCase().includes(lowerTerm)
      );
    }

    return filtered.sort((a, b) => {
      if (sortBy === 'score') return b.score - a.score;
      if (sortBy === 'latest') return b.createdAt - a.createdAt;
      if (sortBy === 'modified') return b.updatedAt - a.updatedAt;
      return 0;
    });
  }, [allProfiles, searchTerm, sortBy]);

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this profile?')) {
      try {
        await deleteProfile(id);
      } catch (error) {
        console.error("Error deleting profile:", error);
        alert("Failed to delete profile.");
      }
    }
  };

  const handleExportCSV = async () => {
    if (!profiles || profiles.length === 0) {
      alert('No profiles to export.');
      return;
    }

    const dynamicHeaders = settings?.questions?.map(q => q.text) || [];
    const conditionalHeaders = settings?.questions?.filter(q => q.hasConditionalField).map(q => `${q.text} (${q.conditionalLabel})`) || [];

    const headers = [
      'Application Number', 'District', 'Name', 'Father Name', 'CNIC', 'Address', 'Phone Number',
      ...dynamicHeaders, ...conditionalHeaders, 'Score', 'Created At', 'Updated At'
    ];

    const escapeCSV = (str: any) => {
      if (str === null || str === undefined) return '';
      const stringified = String(str);
      if (stringified.includes(',') || stringified.includes('"') || stringified.includes('\n')) {
        return `"${stringified.replace(/"/g, '""')}"`;
      }
      return stringified;
    };

    const csvRows = [
      headers.join(','),
      ...profiles.map(p => {
        const dynamicAnswers = settings?.questions?.map(q => p.answers?.[q.id] || '') || [];
        const conditionalAnswers = settings?.questions?.filter(q => q.hasConditionalField).map(q => p.conditionalAnswers?.[q.id] || '') || [];
        
        return [
          p.applicationNumber, p.district, p.name, p.fatherName, p.cnic, p.address, p.phoneNumber,
          ...dynamicAnswers, ...conditionalAnswers, p.score, 
          new Date(p.createdAt).toLocaleString(), new Date(p.updatedAt).toLocaleString()
        ].map(escapeCSV).join(',');
      })
    ];

    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `zakat-profiles-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-6xl mx-auto space-y-6"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-3xl font-bold text-slate-900">Applicant Profiles</h1>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center px-4 py-2 border border-slate-300 rounded-xl shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" /> Export CSV
          </button>

          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="Search by name, CNIC..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none w-full sm:w-64 transition-all"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <ArrowUpDown className="h-5 w-5 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="py-2 pl-3 pr-8 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white transition-all"
            >
              <option value="score">Highest Score</option>
              <option value="latest">Latest Added</option>
              <option value="modified">Last Modified</option>
            </select>
          </div>
        </div>
      </div>

      {!profiles ? (
        <div className="text-center py-12 text-slate-500">Loading profiles...</div>
      ) : profiles.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-slate-500 mb-4">No profiles found.</p>
          <Link to="/create" className="text-emerald-600 font-medium hover:text-emerald-700">
            Create a new profile
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {profiles.map(profile => (
            <motion.div 
              key={profile.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-all flex flex-col"
            >
              <div className="p-6 flex-1">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 line-clamp-1">{profile.name}</h3>
                    <p className="text-sm text-slate-500">{profile.cnic}</p>
                  </div>
                  <div className="bg-emerald-100 text-emerald-800 text-xl font-black px-3 py-1 rounded-lg">
                    {profile.score}
                  </div>
                </div>
                
                <div className="space-y-2 text-sm text-slate-600">
                  <p><span className="font-medium">App No:</span> {profile.applicationNumber}</p>
                  <p><span className="font-medium">District:</span> {profile.district}</p>
                  <p className="text-xs text-slate-400 mt-4">
                    Added: {new Date(profile.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              
              <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex justify-between items-center">
                <Link 
                  to={`/profiles/${profile.id}`}
                  className="text-emerald-600 hover:text-emerald-700 font-medium text-sm flex items-center"
                >
                  <Eye className="w-4 h-4 mr-1" /> View
                </Link>
                <div className="flex space-x-3">
                  <Link 
                    to={`/edit/${profile.id}`}
                    className="text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                  </Link>
                  <button 
                    onClick={() => handleDelete(profile.id!)}
                    className="text-red-600 hover:text-red-700 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
