import { useState, useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { Settings as SettingsType, FormQuestion } from '../db';
import { useSettings, updateSettings } from '../hooks/useFirebase';
import { motion } from 'motion/react';
import { Save, Settings as SettingsIcon, Plus, Trash2, ArrowUp, ArrowDown } from 'lucide-react';

export function Settings() {
  const settings = useSettings();

  const { register, control, handleSubmit, reset, watch } = useForm<SettingsType>();
  const { fields, append, remove, move } = useFieldArray({
    control,
    name: "questions"
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      reset(settings);
    }
  }, [settings, reset]);

  const onSubmit = async (data: SettingsType) => {
    setIsSaving(true);
    try {
      await updateSettings(data);
      alert('Settings saved successfully. New profiles will use these questions and weights.');
    } catch (error) {
      console.error('Failed to save settings:', error);
      alert('Failed to save settings.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!settings) return <div className="p-8 text-center">Loading settings...</div>;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-8"
    >
      <div className="flex items-center space-x-4 mb-8">
        <div className="p-3 bg-slate-200 text-slate-700 rounded-2xl">
          <SettingsIcon className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Form & Scoring Settings</h1>
          <p className="text-slate-500 mt-1">Customize the questions and their point weights for the Need Score calculation.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8 bg-white p-6 sm:p-8 rounded-2xl shadow-sm border border-slate-200">
        
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <h3 className="text-xl font-semibold text-slate-800">Questions</h3>
            <button
              type="button"
              onClick={() => append({ 
                id: Date.now().toString(), 
                text: 'New Question', 
                type: 'boolean', 
                scoreIfTrue: 10,
                options: [{ label: 'Option 1', score: 0 }, { label: 'Option 2', score: 10 }]
              })}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-xl text-emerald-700 bg-emerald-100 hover:bg-emerald-200 focus:outline-none transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Question
            </button>
          </div>
          
          <div className="space-y-6">
            {fields.map((field, index) => {
              const questionType = watch(`questions.${index}.type`);
              const hasConditional = watch(`questions.${index}.hasConditionalField`);

              return (
                <div key={field.id} className="bg-slate-50 p-6 rounded-2xl border border-slate-200 relative shadow-sm">
                  <div className="absolute top-4 right-4 flex space-x-2">
                    <button
                      type="button"
                      onClick={() => move(index, index - 1)}
                      disabled={index === 0}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-200 transition-colors disabled:opacity-30"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => move(index, index + 1)}
                      disabled={index === fields.length - 1}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-200 transition-colors disabled:opacity-30"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => remove(index)}
                      className="p-1.5 text-red-500 hover:text-red-700 rounded-md hover:bg-red-50 transition-colors ml-2"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="space-y-5 pr-24">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Question Text</label>
                        <input
                          type="text"
                          {...register(`questions.${index}.text` as const, { required: true })}
                          className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                        />
                        <input type="hidden" {...register(`questions.${index}.id` as const)} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
                        <select
                          {...register(`questions.${index}.type` as const)}
                          className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 bg-white"
                        >
                          <option value="boolean">Yes/No (Boolean)</option>
                          <option value="select">Multiple Choice (Select)</option>
                        </select>
                      </div>
                    </div>
                    
                    {questionType === 'boolean' && (
                      <div className="bg-white p-4 rounded-xl border border-slate-200">
                        <label className="block text-sm font-medium text-slate-700 mb-2">Score if Answer is "Yes"</label>
                        <input
                          type="number"
                          {...register(`questions.${index}.scoreIfTrue` as const, { valueAsNumber: true })}
                          className="w-32 px-4 py-2 border border-slate-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                        />
                      </div>
                    )}

                    {questionType === 'select' && (
                      <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                        <div className="flex items-center justify-between mb-2">
                          <label className="block text-sm font-medium text-slate-700">Options & Scores</label>
                        </div>
                        <OptionsEditor control={control} register={register} questionIndex={index} />
                      </div>
                    )}

                    <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-4">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id={`conditional-${index}`}
                          {...register(`questions.${index}.hasConditionalField` as const)}
                          className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-slate-300 rounded"
                        />
                        <label htmlFor={`conditional-${index}`} className="ml-2 block text-sm text-slate-700">
                          Add a conditional follow-up field
                        </label>
                      </div>

                      {hasConditional && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-slate-100">
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Show when answer is</label>
                            <input
                              type="text"
                              {...register(`questions.${index}.conditionalTrigger` as const)}
                              placeholder="e.g., Yes"
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Field Label</label>
                            <input
                              type="text"
                              {...register(`questions.${index}.conditionalLabel` as const)}
                              placeholder="e.g., Amount"
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Field Type</label>
                            <select
                              {...register(`questions.${index}.conditionalType` as const)}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 bg-white"
                            >
                              <option value="number">Number</option>
                              <option value="text">Text</option>
                            </select>
                          </div>
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              );
            })}
            {fields.length === 0 && (
              <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                <p className="text-slate-500">No questions configured. Click "Add Question" to start.</p>
              </div>
            )}
          </div>
        </div>

        <div className="pt-6 border-t border-slate-200 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 disabled:opacity-50 transition-colors"
          >
            <Save className="w-5 h-5 mr-2" />
            {isSaving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>

      </form>
    </motion.div>
  );
}

function OptionsEditor({ control, register, questionIndex }: { control: any, register: any, questionIndex: number }) {
  const { fields, append, remove } = useFieldArray({
    control,
    name: `questions.${questionIndex}.options`
  });

  return (
    <div className="space-y-3">
      {fields.map((field, optionIndex) => (
        <div key={field.id} className="flex items-center space-x-3">
          <input
            type="text"
            {...register(`questions.${questionIndex}.options.${optionIndex}.label` as const, { required: true })}
            className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500"
            placeholder="Option Label"
          />
          <input
            type="number"
            {...register(`questions.${questionIndex}.options.${optionIndex}.score` as const, { valueAsNumber: true })}
            className="w-24 px-3 py-2 border border-slate-300 rounded-lg text-right focus:ring-emerald-500 focus:border-emerald-500"
            placeholder="Score"
          />
          <button
            type="button"
            onClick={() => remove(optionIndex)}
            className="p-2 text-red-500 hover:text-red-700 rounded-md hover:bg-red-50 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      ))}
      <button
        type="button"
        onClick={() => append({ label: 'New Option', score: 0 })}
        className="text-sm text-emerald-600 hover:text-emerald-700 font-medium"
      >
        + Add Option
      </button>
    </div>
  );
}
