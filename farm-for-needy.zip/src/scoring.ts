import { Profile, Settings } from './db';

export function calculateScore(profile: Partial<Profile>, settings: Settings): { score: number; breakdown: Record<string, number> } {
  let score = 0;
  const breakdown: Record<string, number> = {};

  if (!settings.questions || !profile.answers) {
    return { score, breakdown };
  }

  settings.questions.forEach(q => {
    const answer = profile.answers?.[q.id];
    let pts = 0;

    if (answer) {
      if (q.type === 'select' && q.options) {
        const option = q.options.find(o => o.label === answer);
        if (option) {
          pts = option.score;
        }
      } else if (q.type === 'boolean') {
        if (answer === 'Yes' && q.scoreIfTrue !== undefined) {
          pts = q.scoreIfTrue;
        }
      }
    }

    score += pts;
    breakdown[q.text] = pts;
  });

  return { score, breakdown };
}
