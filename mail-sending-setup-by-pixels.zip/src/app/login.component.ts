import { Component, inject, signal } from '@angular/core';
import { AuthService } from './auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  template: `
    <div class="min-h-screen flex items-center justify-center bg-slate-50">
      <div class="max-w-md w-full p-8 bg-white rounded-2xl shadow-sm border border-slate-100 text-center">
        <h1 class="text-3xl font-bold text-slate-900 mb-2">Mail sending setup by Pixels</h1>
        <p class="text-slate-500 mb-8">Mail sending setup by Pixels</p>
        
        <form (ngSubmit)="onSubmit()" class="space-y-4 text-left">
          <div>
            <label for="username" class="block text-sm font-medium text-slate-700 mb-1">Username</label>
            <input 
              id="username" 
              type="text" 
              [(ngModel)]="username" 
              name="username"
              class="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              required>
          </div>
          
          <div>
            <label for="password" class="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input 
              id="password" 
              type="password" 
              [(ngModel)]="password" 
              name="password"
              class="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              required>
          </div>

          @if (error()) {
            <p class="text-red-500 text-sm">{{ error() }}</p>
          }

          <button 
            type="submit"
            [disabled]="isLoading()"
            class="w-full flex items-center justify-center gap-3 bg-slate-900 text-white px-6 py-3 rounded-xl hover:bg-slate-800 transition-colors disabled:opacity-50 mt-6">
            @if (isLoading()) {
              <svg class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Signing in...
            } @else {
              Sign in
            }
          </button>
        </form>
      </div>
    </div>
  `
})
export class LoginComponent {
  auth = inject(AuthService);
  
  username = '';
  password = '';
  error = signal('');
  isLoading = signal(false);

  async onSubmit() {
    this.error.set('');
    this.isLoading.set(true);
    try {
      await this.auth.loginWithHardcoded(this.username, this.password);
    } catch (err: any) {
      console.error(err);
      this.error.set(err.message || 'Authentication failed.');
      this.isLoading.set(false);
    }
  }
}
