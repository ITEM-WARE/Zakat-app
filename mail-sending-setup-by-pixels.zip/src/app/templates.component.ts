import { Component, inject, OnInit, signal } from '@angular/core';
import { FirestoreService } from './firestore.service';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Template } from './models';

@Component({
  selector: 'app-templates',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="p-8 max-w-5xl mx-auto">
      <div class="flex justify-between items-center mb-8">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Email Templates</h1>
          <p class="text-slate-500">Manage warning and phishing templates</p>
        </div>
        <button (click)="isAdding.set(true)" class="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700">
          <mat-icon>add</mat-icon> Add Template
        </button>
      </div>

      @if (isAdding()) {
        <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8">
          <h2 class="text-lg font-semibold mb-4">Add Template</h2>
          <form [formGroup]="templateForm" (ngSubmit)="saveTemplate()" class="grid grid-cols-1 gap-4">
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Name</label>
                <input id="name" type="text" formControlName="name" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="e.g., Warning Email 1">
              </div>
              <div>
                <label for="type" class="block text-sm font-medium text-slate-700 mb-1">Type</label>
                <select id="type" formControlName="type" class="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                  <option value="warning">Warning (Part 1)</option>
                  <option value="phishing">Phishing (Part 2)</option>
                </select>
              </div>
            </div>
            <div>
              <label for="subject" class="block text-sm font-medium text-slate-700 mb-1">Subject</label>
              <input id="subject" type="text" formControlName="subject" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="Important Security Update">
            </div>
            <div>
              <label for="htmlBody" class="block text-sm font-medium text-slate-700 mb-1">HTML Body</label>
              <textarea id="htmlBody" formControlName="htmlBody" rows="6" class="w-full border border-slate-300 rounded-lg px-3 py-2 font-mono text-sm" placeholder="<html>...</html>"></textarea>
            </div>
            <div class="flex justify-end gap-3 mt-4">
              <button type="button" (click)="cancelAdd()" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button type="submit" [disabled]="templateForm.invalid" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50">Save</button>
            </div>
          </form>
        </div>
      }

      <div class="grid gap-4">
        @for (template of templates(); track template.id) {
          <div class="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex justify-between items-center">
            <div>
              <div class="flex items-center gap-3">
                <h3 class="font-semibold text-slate-900">{{template.name}}</h3>
                <span class="px-2 py-1 text-xs rounded-full" [ngClass]="template.type === 'warning' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'">
                  {{template.type === 'warning' ? 'Warning' : 'Phishing'}}
                </span>
              </div>
              <p class="text-sm text-slate-500 mt-1">Subject: {{template.subject}}</p>
            </div>
            <div class="flex gap-2">
              <button (click)="deleteTemplate(template.id)" class="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                <mat-icon>delete</mat-icon>
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class TemplatesComponent implements OnInit {
  firestore = inject(FirestoreService);
  fb = inject(FormBuilder);

  templates = signal<Template[]>([]);
  isAdding = signal(false);

  templateForm = this.fb.group({
    name: ['', Validators.required],
    subject: ['', Validators.required],
    htmlBody: ['', Validators.required],
    type: ['warning', Validators.required]
  });

  ngOnInit() {
    this.firestore.getTemplates((data) => {
      this.templates.set(data as Template[]);
    });
  }

  cancelAdd() {
    this.isAdding.set(false);
    this.templateForm.reset({ type: 'warning' });
  }

  async saveTemplate() {
    if (this.templateForm.valid) {
      await this.firestore.addTemplate(this.templateForm.value);
      this.cancelAdd();
    }
  }

  async deleteTemplate(id: string) {
    if (confirm('Are you sure you want to delete this template?')) {
      await this.firestore.deleteTemplate(id);
    }
  }
}
