import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { FirestoreService } from './firestore.service';
import { EmailService } from './email.service';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Recipient, Template, SmtpServer, RecipientHistory } from './models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="p-8 max-w-6xl mx-auto">
      <div class="flex justify-between items-center mb-8">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Recipients</h1>
          <p class="text-slate-500">Manage targets and send campaigns</p>
        </div>
        <div class="flex gap-3">
          <button (click)="isAdding.set(true)" class="bg-white text-slate-700 border border-slate-300 px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-slate-50">
            <mat-icon>person_add</mat-icon> Add Recipient
          </button>
          <button (click)="massSendWarning()" [disabled]="isSending()" class="bg-amber-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-amber-600 disabled:opacity-50">
            <mat-icon>campaign</mat-icon> Mass Send Warning
          </button>
        </div>
      </div>

      @if (isAdding()) {
        <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8">
          <h2 class="text-lg font-semibold mb-4">Add Recipient</h2>
          <form [formGroup]="recipientForm" (ngSubmit)="saveRecipient()" class="grid grid-cols-2 gap-4">
            <div>
              <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Name</label>
              <input id="name" type="text" formControlName="name" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="John Doe">
            </div>
            <div>
              <label for="email" class="block text-sm font-medium text-slate-700 mb-1">Email</label>
              <input id="email" type="email" formControlName="email" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="john@company.com">
            </div>
            <div class="col-span-2 flex justify-end gap-3 mt-4">
              <button type="button" (click)="cancelAdd()" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button type="submit" [disabled]="recipientForm.invalid" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50">Save</button>
            </div>
          </form>
        </div>
      }

      <!-- Search -->
      <div class="mb-6">
        <div class="relative">
          <mat-icon class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">search</mat-icon>
          <input type="text" [formControl]="searchControl" placeholder="Search by name or email..." class="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
        </div>
      </div>

      <!-- List -->
      <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table class="w-full text-left">
          <thead class="bg-slate-50 border-b border-slate-200">
            <tr>
              <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
              <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Email</th>
              <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
              <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-200">
            @for (recipient of filteredRecipients(); track recipient.id) {
              <tr class="hover:bg-slate-50 transition-colors">
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="font-medium text-slate-900">{{recipient.name}}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-slate-500">{{recipient.email}}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="px-2 py-1 text-xs rounded-full" 
                    [ngClass]="{
                      'bg-slate-100 text-slate-600': recipient.status === 'pending',
                      'bg-amber-100 text-amber-700': recipient.status === 'warning_sent',
                      'bg-red-100 text-red-700': recipient.status === 'phishing_sent'
                    }">
                    {{recipient.status.replace('_', ' ') | uppercase}}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right">
                  <button (click)="sendPhishing(recipient)" [disabled]="isSending()" class="text-indigo-600 hover:text-indigo-900 font-medium text-sm disabled:opacity-50">
                    Send Phishing
                  </button>
                </td>
              </tr>
            }
            @if (filteredRecipients().length === 0) {
              <tr>
                <td colspan="4" class="px-6 py-8 text-center text-slate-500">No recipients found.</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class DashboardComponent implements OnInit {
  firestore = inject(FirestoreService);
  emailService = inject(EmailService);
  fb = inject(FormBuilder);

  recipients = signal<Recipient[]>([]);
  templates = signal<Template[]>([]);
  smtpServers = signal<SmtpServer[]>([]);
  
  isAdding = signal(false);
  isSending = signal(false);

  searchControl = this.fb.control('');
  searchTerm = signal('');

  recipientForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    status: ['pending'],
    history: [[] as RecipientHistory[]]
  });

  filteredRecipients = computed(() => {
    const term = this.searchTerm().toLowerCase();
    return this.recipients().filter(r => 
      r.name.toLowerCase().includes(term) || 
      r.email.toLowerCase().includes(term)
    );
  });

  ngOnInit() {
    this.firestore.getRecipients((data) => this.recipients.set(data as Recipient[]));
    this.firestore.getTemplates((data) => this.templates.set(data as Template[]));
    this.firestore.getSmtpServers((data) => {
      this.smtpServers.set((data as SmtpServer[]).filter(s => s.isActive).sort((a, b) => a.rotationOrder - b.rotationOrder));
    });

    this.searchControl.valueChanges.subscribe(val => {
      this.searchTerm.set(val || '');
    });
  }

  cancelAdd() {
    this.isAdding.set(false);
    this.recipientForm.reset({ status: 'pending', history: [] as RecipientHistory[] });
  }

  async saveRecipient() {
    if (this.recipientForm.valid) {
      await this.firestore.addRecipient(this.recipientForm.value);
      this.cancelAdd();
    }
  }

  // Round-robin SMTP selection
  currentSmtpIndex = 0;
  getNextSmtpServer() {
    const servers = this.smtpServers();
    if (servers.length === 0) return null;
    const server = servers[this.currentSmtpIndex % servers.length];
    this.currentSmtpIndex++;
    return server;
  }

  async massSendWarning() {
    const warningTemplates = this.templates().filter(t => t.type === 'warning');
    if (warningTemplates.length === 0) {
      alert('Please create a Warning template first.');
      return;
    }
    if (this.smtpServers().length === 0) {
      alert('Please add at least one active SMTP server.');
      return;
    }

    if (!confirm('Are you sure you want to mass send the warning email to ALL pending recipients?')) return;

    this.isSending.set(true);
    const template = warningTemplates[0]; // Use the first warning template
    const pendingRecipients = this.recipients().filter(r => r.status === 'pending');

    let successCount = 0;
    let failCount = 0;

    for (const recipient of pendingRecipients) {
      const smtp = this.getNextSmtpServer();
      try {
        await this.emailService.sendEmail(recipient.email, template.subject, template.htmlBody, smtp);
        
        // Update recipient
        const history = [...(recipient.history || []), {
          templateId: template.id,
          sentAt: new Date().toISOString(),
          smtpUsed: smtp ? smtp.host : 'unknown'
        }];
        await this.firestore.updateRecipient(recipient.id, { status: 'warning_sent', history });
        successCount++;
      } catch (error) {
        console.error('Failed to send to', recipient.email, error);
        failCount++;
      }
    }

    this.isSending.set(false);
    alert(`Mass send complete. Success: ${successCount}, Failed: ${failCount}`);
  }

  async sendPhishing(recipient: Recipient) {
    const phishingTemplates = this.templates().filter(t => t.type === 'phishing');
    if (phishingTemplates.length === 0) {
      alert('Please create a Phishing template first.');
      return;
    }
    if (this.smtpServers().length === 0) {
      alert('Please add at least one active SMTP server.');
      return;
    }

    if (!confirm(`Send phishing email to ${recipient.name}?`)) return;

    this.isSending.set(true);
    const template = phishingTemplates[0]; // Use first phishing template
    const smtp = this.getNextSmtpServer();

    try {
      await this.emailService.sendEmail(recipient.email, template.subject, template.htmlBody, smtp);
      
      const history = [...(recipient.history || []), {
        templateId: template.id,
        sentAt: new Date().toISOString(),
        smtpUsed: smtp ? smtp.host : 'unknown'
      }];
      await this.firestore.updateRecipient(recipient.id, { status: 'phishing_sent', history });
      alert('Phishing email sent successfully.');
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      alert('Failed to send email: ' + errorMessage);
    }
    this.isSending.set(false);
  }
}
