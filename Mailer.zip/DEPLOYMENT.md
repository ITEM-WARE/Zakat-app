# Deployment Guide for VPS

This guide will help you deploy the "Mail sending setup by Pixels" application to your VPS at `/root/Mailing` with the domain `Mailsender.ne-t.org`.

## Prerequisites
Ensure your VPS has the following installed:
- Node.js (v18 or higher recommended)
- npm
- Nginx
- PM2 (Process Manager for Node.js)

If you don't have PM2 installed, you can install it globally:
```bash
npm install -g pm2
```

## Step 1: Transfer Files
Upload all the project files from your local machine to your VPS in the `/root/Mailing` directory. You can use `scp`, `rsync`, or an FTP client.

## Step 2: Install Dependencies and Build
SSH into your VPS and navigate to the project directory:
```bash
cd /root/Mailing
```

Install the required npm packages:
```bash
npm install
```

Build the Angular SSR application:
```bash
npm run build
```

## Step 3: Start the Server with PM2
Start the built Node.js server using PM2 so it runs in the background and restarts automatically if it crashes:

```bash
pm2 start dist/ai-studio-angular-app/server/server.mjs --name "mailsender" --env PORT=4000
```

Save the PM2 process list so it starts on server reboot:
```bash
pm2 save
pm2 startup
```

## Step 4: Configure Nginx
Create a new Nginx configuration file for your domain.

```bash
nano /etc/nginx/sites-available/mailsender
```

Paste the following configuration into the file:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name Mailsender.ne-t.org;

    location / {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Save and exit (`Ctrl+O`, `Enter`, `Ctrl+X`).

Enable the site by creating a symlink to `sites-enabled`:
```bash
ln -s /etc/nginx/sites-available/mailsender /etc/nginx/sites-enabled/
```

Test the Nginx configuration to ensure there are no syntax errors:
```bash
nginx -t
```

If the test is successful, reload Nginx to apply the changes:
```bash
systemctl reload nginx
```

## Step 5: Secure with SSL (Optional but Recommended)
If you want to secure your domain with HTTPS using Let's Encrypt, run:
```bash
certbot --nginx -d Mailsender.ne-t.org
```

Your application should now be live at `http://Mailsender.ne-t.org`!
