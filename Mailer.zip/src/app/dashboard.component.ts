import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { FirestoreService } from './firestore.service';
import { EmailService } from './email.service';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Recipient, Template, SmtpServer, RecipientHistory } from './models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="p-4 md:p-8 max-w-6xl mx-auto">
      @if (connectionError()) {
        <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl mb-8 flex items-center gap-3">
          <mat-icon>error</mat-icon>
          <div>
            <p class="font-bold">Connection Error</p>
            <p class="text-sm">{{connectionError()}}</p>
          </div>
        </div>
      }

      <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Recipients</h1>
          <p class="text-slate-500">Manage targets and send campaigns</p>
        </div>
        <div class="flex flex-wrap gap-2 w-full lg:w-auto">
          <input type="file" #fileInput (change)="onFileSelected($event)" accept=".csv" class="hidden">
          <button (click)="fileInput.click()" class="flex-1 lg:flex-none bg-white text-slate-700 border border-slate-300 px-3 py-2 rounded-lg flex items-center justify-center gap-2 hover:bg-slate-50 text-sm">
            <mat-icon class="text-lg">upload_file</mat-icon> Bulk CSV
          </button>
          <button (click)="isAdding.set(true)" class="flex-1 lg:flex-none bg-white text-slate-700 border border-slate-300 px-3 py-2 rounded-lg flex items-center justify-center gap-2 hover:bg-slate-50 text-sm">
            <mat-icon class="text-lg">person_add</mat-icon> Add
          </button>
          <button (click)="massSendWarning()" [disabled]="isSending()" class="flex-1 lg:flex-none bg-amber-500 text-white px-3 py-2 rounded-lg flex items-center justify-center gap-2 hover:bg-amber-600 disabled:opacity-50 text-sm">
            <mat-icon class="text-lg">campaign</mat-icon> Mass Warning
          </button>
          <button (click)="isBulkSending.set(true)" [disabled]="isSending()" class="flex-1 lg:flex-none bg-indigo-600 text-white px-3 py-2 rounded-lg flex items-center justify-center gap-2 hover:bg-indigo-700 disabled:opacity-50 text-sm">
            <mat-icon class="text-lg">send</mat-icon> Bulk Send
          </button>
        </div>
      </div>

        @if (bulkProgress().active) {
          <div class="bg-indigo-50 border border-indigo-100 p-4 rounded-xl mb-8">
            <div class="flex justify-between items-center mb-2">
              <span class="text-sm font-medium text-indigo-900">Sending Campaign...</span>
              <span class="text-sm text-indigo-700">{{bulkProgress().current}} / {{bulkProgress().total}}</span>
            </div>
            <div class="w-full bg-indigo-200 rounded-full h-2">
              <div class="bg-indigo-600 h-2 rounded-full transition-all duration-300" [style.width.%]="(bulkProgress().current / bulkProgress().total) * 100"></div>
            </div>
          </div>
        }

      @if (isAdding()) {
        <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8">
          <h2 class="text-lg font-semibold mb-4">Add Recipient</h2>
          <form [formGroup]="recipientForm" (ngSubmit)="saveRecipient()" class="grid grid-cols-2 gap-4">
            <div>
              <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Name</label>
              <input id="name" type="text" formControlName="name" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="John Doe">
            </div>
            <div>
              <label for="email" class="block text-sm font-medium text-slate-700 mb-1">Email</label>
              <input id="email" type="email" formControlName="email" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="john@company.com">
            </div>
            <div class="col-span-2 flex justify-end gap-3 mt-4">
              <button type="button" (click)="cancelAdd()" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button type="submit" [disabled]="recipientForm.invalid" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50">Save</button>
            </div>
          </form>
        </div>
      }

      <!-- Search -->
      <div class="mb-6">
        <div class="relative">
          <mat-icon class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">search</mat-icon>
          <input type="text" [formControl]="searchControl" placeholder="Search by name or email..." class="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
        </div>
      </div>

      <!-- List -->
      <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left min-w-[600px]">
            <thead class="bg-slate-50 border-b border-slate-200">
              <tr>
                <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Email</th>
                <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                <th class="px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
              @for (recipient of filteredRecipients(); track recipient.id) {
                <tr class="hover:bg-slate-50 transition-colors">
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="font-medium text-slate-900">{{recipient.name}}</div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-slate-500">{{recipient.email}}</td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 py-1 text-xs rounded-full" 
                      [ngClass]="{
                        'bg-slate-100 text-slate-600': recipient.status === 'pending',
                        'bg-amber-100 text-amber-700': recipient.status === 'warning_sent',
                        'bg-red-100 text-red-700': recipient.status === 'phishing_sent'
                      }">
                      {{recipient.status.replace('_', ' ') | uppercase}}
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-right flex justify-end gap-2">
                    <button (click)="viewHistory(recipient)" title="View History" class="text-slate-400 hover:text-slate-600">
                      <mat-icon class="text-lg">history</mat-icon>
                    </button>
                    <button (click)="sendWarning(recipient)" [disabled]="isSending()" title="Send Warning" class="text-amber-500 hover:text-amber-700 disabled:opacity-50">
                      <mat-icon class="text-lg">report_problem</mat-icon>
                    </button>
                    <button (click)="sendPhishing(recipient)" [disabled]="isSending()" title="Send Phishing" class="text-indigo-600 hover:text-indigo-900 disabled:opacity-50">
                      <mat-icon class="text-lg">send</mat-icon>
                    </button>
                    <button (click)="deleteRecipient(recipient.id)" class="text-red-400 hover:text-red-600">
                      <mat-icon class="text-lg">delete</mat-icon>
                    </button>
                  </td>
                </tr>
              }
              @if (filteredRecipients().length === 0) {
                <tr>
                  <td colspan="4" class="px-6 py-8 text-center text-slate-500">No recipients found.</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      @if (selectedRecipientForHistory()) {
        <div class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div class="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div class="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 class="text-xl font-bold text-slate-900">Sent History</h3>
              <button (click)="selectedRecipientForHistory.set(null)" class="text-slate-400 hover:text-slate-600">
                <mat-icon>close</mat-icon>
              </button>
            </div>
            <div class="p-6 max-h-[60vh] overflow-y-auto">
              <div class="space-y-4">
                @for (item of selectedRecipientForHistory()?.history; track item.sentAt) {
                  <div class="flex gap-4 p-3 rounded-lg bg-slate-50 border border-slate-100">
                    <div class="bg-indigo-100 text-indigo-600 p-2 rounded-lg h-fit">
                      <mat-icon>mail</mat-icon>
                    </div>
                    <div>
                      <div class="font-medium text-slate-900">{{getTemplateName(item.templateId)}}</div>
                      <div class="text-xs text-slate-500">{{item.sentAt | date:'medium'}}</div>
                      <div class="text-xs text-slate-400 mt-1">Via: {{item.smtpUsed}}</div>
                    </div>
                  </div>
                }
                @if (!selectedRecipientForHistory()?.history?.length) {
                  <div class="text-center py-8 text-slate-400 italic">No emails sent yet.</div>
                }
              </div>
            </div>
            <div class="p-6 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button (click)="selectedRecipientForHistory.set(null)" class="bg-white border border-slate-200 px-6 py-2 rounded-xl font-medium text-slate-700 hover:bg-slate-50 transition-all">
                Close
              </button>
            </div>
          </div>
        </div>
      }

      @if (isBulkSending()) {
        <div class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div class="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div class="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 class="text-xl font-bold text-slate-900">Bulk Send Campaign</h3>
              <button (click)="isBulkSending.set(false)" class="text-slate-400 hover:text-slate-600">
                <mat-icon>close</mat-icon>
              </button>
            </div>
            <div class="p-6">
              <label for="bulkTemplate" class="block text-sm font-medium text-slate-700 mb-2">Select Template</label>
              <select id="bulkTemplate" #templateSelect class="w-full border border-slate-300 rounded-lg px-3 py-2 mb-4">
                @for (t of templates(); track t.id) {
                  <option [value]="t.id">{{t.name}} ({{t.type}})</option>
                }
              </select>
              <p class="text-sm text-slate-500 mb-4">
                This will send the selected template to all <strong>{{filteredRecipients().length}}</strong> recipients currently visible in your list.
              </p>
            </div>
            <div class="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button (click)="isBulkSending.set(false)" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button (click)="startBulkSend(templateSelect.value)" class="bg-indigo-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-indigo-700 transition-all">
                Start Sending
              </button>
            </div>
          </div>
        </div>
      }

      <!-- Toast Notification -->
      @if (notification()) {
        <div class="fixed bottom-8 right-8 z-[100] animate-bounce">
          <div class="px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 border"
            [ngClass]="{
              'bg-emerald-600 text-white border-emerald-500': notification()?.type === 'success',
              'bg-red-600 text-white border-red-500': notification()?.type === 'error',
              'bg-slate-800 text-white border-slate-700': notification()?.type === 'info'
            }">
            <mat-icon>{{ notification()?.type === 'success' ? 'check_circle' : notification()?.type === 'error' ? 'error' : 'info' }}</mat-icon>
            <span class="font-medium">{{notification()?.message}}</span>
          </div>
        </div>
      }

      <!-- Confirmation Modal -->
      @if (confirmModal()) {
        <div class="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4">
          <div class="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div class="p-6">
              <h3 class="text-xl font-bold text-slate-900 mb-2">{{confirmModal()?.title}}</h3>
              <p class="text-slate-600">{{confirmModal()?.message}}</p>
            </div>
            <div class="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button (click)="confirmModal.set(null)" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button (click)="confirmModal()?.onConfirm(); confirmModal.set(null)" class="bg-indigo-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-indigo-700">
                Confirm
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class DashboardComponent implements OnInit {
  firestore = inject(FirestoreService);
  emailService = inject(EmailService);
  fb = inject(FormBuilder);

  recipients = signal<Recipient[]>([]);
  templates = signal<Template[]>([]);
  smtpServers = signal<SmtpServer[]>([]);
  
  isAdding = signal(false);
  isSending = signal(false);
  isBulkSending = signal(false);
  bulkProgress = signal({ current: 0, total: 0, active: false });
  selectedRecipientForHistory = signal<Recipient | null>(null);
  
  // Custom Modal/Toast signals
  notification = signal<{ message: string, type: 'success' | 'error' | 'info' } | null>(null);
  confirmModal = signal<{ title: string, message: string, onConfirm: () => void } | null>(null);
  connectionError = signal<string | null>(null);

  searchControl = this.fb.control('');
  searchTerm = signal('');

  recipientForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    status: ['pending'],
    history: [[] as RecipientHistory[]]
  });

  filteredRecipients = computed(() => {
    const term = this.searchTerm().toLowerCase();
    return this.recipients().filter(r => 
      r.name.toLowerCase().includes(term) || 
      r.email.toLowerCase().includes(term)
    );
  });

  ngOnInit() {
    this.firestore.getRecipients((data) => {
      this.recipients.set(data as Recipient[]);
      this.connectionError.set(null);
    }, (error: unknown) => {
      console.error('Firestore connection error:', error);
      this.connectionError.set("Could not reach Cloud Firestore backend. Please check your connection.");
    });
    
    this.firestore.getTemplates((data) => this.templates.set(data as Template[]));
    this.firestore.getSmtpServers((data) => {
      this.smtpServers.set((data as SmtpServer[]).filter(s => s.isActive).sort((a, b) => a.rotationOrder - b.rotationOrder));
    });

    this.searchControl.valueChanges.subscribe(val => {
      this.searchTerm.set(val || '');
    });
  }

  showNotification(message: string, type: 'success' | 'error' | 'info' = 'info') {
    this.notification.set({ message, type });
    setTimeout(() => this.notification.set(null), 5000);
  }

  showConfirm(title: string, message: string, onConfirm: () => void) {
    this.confirmModal.set({ title, message, onConfirm });
  }

  getTemplateName(id: string) {
    return this.templates().find(t => t.id === id)?.name || 'Unknown Template';
  }

  viewHistory(recipient: Recipient) {
    this.selectedRecipientForHistory.set(recipient);
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        this.parseCSV(text);
      };
      reader.readAsText(file);
    }
    input.value = ''; // Reset input
  }

  async parseCSV(text: string) {
    const lines = text.split('\n');
    const newRecipients: Partial<Recipient>[] = [];
    for (const line of lines) {
      const parts = line.split(',');
      if (parts.length >= 2) {
        const name = parts[0].trim();
        const email = parts[1].trim();
        if (name && email && email.includes('@')) {
          newRecipients.push({ name, email, status: 'pending', history: [] });
        }
      }
    }
    
    if (newRecipients.length > 0) {
      this.showConfirm(
        'Bulk Add', 
        `Found ${newRecipients.length} recipients. Add them to the list?`,
        async () => {
          for (const r of newRecipients) {
            await this.firestore.addRecipient(r);
          }
          this.showNotification(`Added ${newRecipients.length} recipients.`, 'success');
        }
      );
    } else {
      this.showNotification('No valid recipients found in CSV. Format should be: Name, Email', 'error');
    }
  }

  cancelAdd() {
    this.isAdding.set(false);
    this.recipientForm.reset({ status: 'pending', history: [] as RecipientHistory[] });
  }

  async saveRecipient() {
    if (this.recipientForm.valid) {
      await this.firestore.addRecipient(this.recipientForm.value);
      this.showNotification('Recipient added successfully.', 'success');
      this.cancelAdd();
    }
  }

  // Round-robin SMTP selection
  currentSmtpIndex = 0;
  getNextSmtpServer() {
    const servers = this.smtpServers();
    if (servers.length === 0) return null;
    const server = servers[this.currentSmtpIndex % servers.length];
    this.currentSmtpIndex++;
    return server;
  }

  async massSendWarning() {
    console.log('Mass Send Warning clicked');
    const warningTemplates = this.templates().filter(t => t.type === 'warning');
    if (warningTemplates.length === 0) {
      console.warn('No warning templates found');
      this.showNotification('Please create a Warning template first.', 'error');
      return;
    }
    if (this.smtpServers().length === 0) {
      console.warn('No active SMTP servers found');
      this.showNotification('Please add at least one active SMTP server.', 'error');
      return;
    }

    const pendingRecipients = this.recipients().filter(r => r.status === 'pending');
    if (pendingRecipients.length === 0) {
      console.warn('No pending recipients found');
      this.showNotification('No pending recipients found.', 'info');
      return;
    }

    this.showConfirm(
      'Mass Send Warning',
      `Are you sure you want to mass send the warning email to ${pendingRecipients.length} pending recipients?`,
      async () => {
        console.log('Mass Send Warning confirmed');
        this.isSending.set(true);
        this.bulkProgress.set({ current: 0, total: pendingRecipients.length, active: true });
        const template = warningTemplates[0]; // Use the first warning template

        let successCount = 0;
        let failCount = 0;

        for (const recipient of pendingRecipients) {
          const smtp = this.getNextSmtpServer();
          try {
            console.log(`Sending warning to ${recipient.email} using ${smtp?.host}`);
            await this.emailService.sendEmail(recipient.email, template.subject, template.htmlBody, smtp);
            
            // Update recipient
            const history = [...(recipient.history || []), {
              templateId: template.id,
              sentAt: new Date().toISOString(),
              smtpUsed: smtp ? smtp.host : 'unknown'
            }];
            await this.firestore.updateRecipient(recipient.id, { status: 'warning_sent', history });
            successCount++;
            console.log(`Successfully sent to ${recipient.email}`);
          } catch (error) {
            console.error('Failed to send to', recipient.email, error);
            failCount++;
          }
          this.bulkProgress.update(p => ({ ...p, current: p.current + 1 }));
        }

        this.isSending.set(false);
        this.bulkProgress.set({ current: 0, total: 0, active: false });
        this.showNotification(`Mass send complete. Success: ${successCount}, Failed: ${failCount}`, successCount > 0 ? 'success' : 'error');
      }
    );
  }

  async startBulkSend(templateId: string) {
    const template = this.templates().find(t => t.id === templateId);
    if (!template) return;
    
    if (this.smtpServers().length === 0) {
      this.showNotification('Please add at least one active SMTP server.', 'error');
      return;
    }

    const targets = this.filteredRecipients();
    if (targets.length === 0) {
      this.showNotification('No recipients in the current view.', 'info');
      return;
    }

    this.showConfirm(
      'Bulk Send',
      `Start sending "${template.name}" to ${targets.length} recipients?`,
      async () => {
        this.isBulkSending.set(false);
        this.isSending.set(true);
        this.bulkProgress.set({ current: 0, total: targets.length, active: true });

        let successCount = 0;
        let failCount = 0;

        for (const recipient of targets) {
          const smtp = this.getNextSmtpServer();
          try {
            await this.emailService.sendEmail(recipient.email, template.subject, template.htmlBody, smtp);
            
            const history = [...(recipient.history || []), {
              templateId: template.id,
              sentAt: new Date().toISOString(),
              smtpUsed: smtp ? smtp.host : 'unknown'
            }];
            
            const newStatus = template.type === 'warning' ? 'warning_sent' : 'phishing_sent';
            await this.firestore.updateRecipient(recipient.id, { status: newStatus, history });
            successCount++;
          } catch (error) {
            console.error('Failed to send to', recipient.email, error);
            failCount++;
          }
          this.bulkProgress.update(p => ({ ...p, current: p.current + 1 }));
        }

        this.isSending.set(false);
        this.bulkProgress.set({ current: 0, total: 0, active: false });
        this.showNotification(`Bulk send complete. Success: ${successCount}, Failed: ${failCount}`, successCount > 0 ? 'success' : 'error');
      }
    );
  }

  async sendPhishing(recipient: Recipient) {
    const phishingTemplates = this.templates().filter(t => t.type === 'phishing');
    if (phishingTemplates.length === 0) {
      this.showNotification('Please create a Phishing template first.', 'error');
      return;
    }
    if (this.smtpServers().length === 0) {
      this.showNotification('Please add at least one active SMTP server.', 'error');
      return;
    }

    this.showConfirm(
      'Send Phishing',
      `Send phishing email to ${recipient.name}?`,
      async () => {
        this.isSending.set(true);
        const template = phishingTemplates[0]; // Use first phishing template
        const smtp = this.getNextSmtpServer();

        try {
          await this.emailService.sendEmail(recipient.email, template.subject, template.htmlBody, smtp);
          
          const history = [...(recipient.history || []), {
            templateId: template.id,
            sentAt: new Date().toISOString(),
            smtpUsed: smtp ? smtp.host : 'unknown'
          }];
          await this.firestore.updateRecipient(recipient.id, { status: 'phishing_sent', history });
          this.showNotification('Phishing email sent successfully.', 'success');
        } catch (error: unknown) {
          const errorMessage = error instanceof Error ? error.message : 'Unknown error';
          this.showNotification('Failed to send email: ' + errorMessage, 'error');
        }
        this.isSending.set(false);
      }
    );
  }

  async sendWarning(recipient: Recipient) {
    const warningTemplates = this.templates().filter(t => t.type === 'warning');
    if (warningTemplates.length === 0) {
      this.showNotification('Please create a Warning template first.', 'error');
      return;
    }
    if (this.smtpServers().length === 0) {
      this.showNotification('Please add at least one active SMTP server.', 'error');
      return;
    }

    this.showConfirm(
      'Send Warning',
      `Send warning email to ${recipient.name}?`,
      async () => {
        this.isSending.set(true);
        const template = warningTemplates[0]; // Use first warning template
        const smtp = this.getNextSmtpServer();

        try {
          await this.emailService.sendEmail(recipient.email, template.subject, template.htmlBody, smtp);
          
          const history = [...(recipient.history || []), {
            templateId: template.id,
            sentAt: new Date().toISOString(),
            smtpUsed: smtp ? smtp.host : 'unknown'
          }];
          await this.firestore.updateRecipient(recipient.id, { status: 'warning_sent', history });
          this.showNotification('Warning email sent successfully.', 'success');
        } catch (error: unknown) {
          const errorMessage = error instanceof Error ? error.message : 'Unknown error';
          this.showNotification('Failed to send email: ' + errorMessage, 'error');
        }
        this.isSending.set(false);
      }
    );
  }

  async deleteRecipient(id: string) {
    this.showConfirm(
      'Delete Recipient',
      'Are you sure you want to delete this recipient?',
      async () => {
        await this.firestore.deleteRecipient(id);
        this.showNotification('Recipient deleted.', 'info');
      }
    );
  }
}
