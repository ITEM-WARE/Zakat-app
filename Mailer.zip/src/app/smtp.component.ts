import { Component, inject, OnInit, signal } from '@angular/core';
import { FirestoreService } from './firestore.service';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SmtpServer } from './models';

@Component({
  selector: 'app-smtp',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="p-4 md:p-8 max-w-5xl mx-auto">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">SMTP Servers</h1>
          <p class="text-slate-500">Manage your rotating SMTP configurations</p>
        </div>
        <button (click)="isAdding.set(true)" class="w-full sm:w-auto bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center justify-center gap-2 hover:bg-indigo-700">
          <mat-icon>add</mat-icon> Add Server
        </button>
      </div>

      @if (isAdding()) {
        <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8">
          <h2 class="text-lg font-semibold mb-4">Add SMTP Server</h2>
          <form [formGroup]="smtpForm" (ngSubmit)="saveServer()" class="grid grid-cols-2 gap-4">
            <div>
              <label for="host" class="block text-sm font-medium text-slate-700 mb-1">Host</label>
              <input id="host" type="text" formControlName="host" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="smtp.example.com">
            </div>
            <div>
              <label for="port" class="block text-sm font-medium text-slate-700 mb-1">Port</label>
              <input id="port" type="number" formControlName="port" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="587">
            </div>
            <div>
              <label for="authUser" class="block text-sm font-medium text-slate-700 mb-1">Username</label>
              <input id="authUser" type="text" formControlName="authUser" class="w-full border border-slate-300 rounded-lg px-3 py-2">
            </div>
            <div>
              <label for="authPass" class="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <input id="authPass" type="password" formControlName="authPass" class="w-full border border-slate-300 rounded-lg px-3 py-2">
            </div>
            <div>
              <label for="rotationOrder" class="block text-sm font-medium text-slate-700 mb-1">Rotation Order</label>
              <input id="rotationOrder" type="number" formControlName="rotationOrder" class="w-full border border-slate-300 rounded-lg px-3 py-2">
            </div>
            <div class="flex items-end gap-4">
              <label class="flex items-center gap-2 mb-2">
                <input type="checkbox" formControlName="isActive" class="rounded text-indigo-600">
                <span class="text-sm font-medium text-slate-700">Active</span>
              </label>
            </div>
            <div class="col-span-2 flex justify-end gap-3 mt-4">
              <button type="button" (click)="cancelAdd()" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button type="submit" [disabled]="smtpForm.invalid" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50">Save</button>
            </div>
          </form>
        </div>
      }

      <div class="grid gap-4">
        @for (server of servers(); track server.id) {
          <div class="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-3 flex-wrap">
                <h3 class="font-semibold text-slate-900 truncate">{{server.host}}</h3>
                <span class="px-2 py-1 text-xs rounded-full whitespace-nowrap" [ngClass]="server.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'">
                  {{server.isActive ? 'Active' : 'Inactive'}}
                </span>
              </div>
              <p class="text-sm text-slate-500 mt-1 truncate">Port: {{server.port}} | User: {{server.authUser}} | Order: {{server.rotationOrder}}</p>
            </div>
            <div class="flex gap-2 self-end sm:self-auto">
              <button (click)="deleteServer(server.id)" class="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                <mat-icon>delete</mat-icon>
              </button>
            </div>
          </div>
        }
      </div>

      <!-- Toast Notification -->
      @if (notification()) {
        <div class="fixed bottom-8 right-8 z-[100] animate-bounce">
          <div class="px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 border"
            [ngClass]="{
              'bg-emerald-600 text-white border-emerald-500': notification()?.type === 'success',
              'bg-red-600 text-white border-red-500': notification()?.type === 'error',
              'bg-slate-800 text-white border-slate-700': notification()?.type === 'info'
            }">
            <mat-icon>{{ notification()?.type === 'success' ? 'check_circle' : notification()?.type === 'error' ? 'error' : 'info' }}</mat-icon>
            <span class="font-medium">{{notification()?.message}}</span>
          </div>
        </div>
      }

      <!-- Confirmation Modal -->
      @if (confirmModal()) {
        <div class="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4">
          <div class="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div class="p-6">
              <h3 class="text-xl font-bold text-slate-900 mb-2">{{confirmModal()?.title}}</h3>
              <p class="text-slate-600">{{confirmModal()?.message}}</p>
            </div>
            <div class="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button (click)="confirmModal.set(null)" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button (click)="confirmModal()?.onConfirm(); confirmModal.set(null)" class="bg-indigo-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-indigo-700">
                Confirm
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class SmtpComponent implements OnInit {
  firestore = inject(FirestoreService);
  fb = inject(FormBuilder);

  servers = signal<SmtpServer[]>([]);
  isAdding = signal(false);
  
  // Custom Modal/Toast signals
  notification = signal<{ message: string, type: 'success' | 'error' | 'info' } | null>(null);
  confirmModal = signal<{ title: string, message: string, onConfirm: () => void } | null>(null);

  smtpForm = this.fb.group({
    host: ['', Validators.required],
    port: [587, Validators.required],
    authUser: ['', Validators.required],
    authPass: ['', Validators.required],
    isActive: [true],
    rotationOrder: [0, Validators.required]
  });

  ngOnInit() {
    this.firestore.getSmtpServers((data) => {
      // Sort by rotation order
      this.servers.set((data as SmtpServer[]).sort((a, b) => a.rotationOrder - b.rotationOrder));
    });
  }

  showNotification(message: string, type: 'success' | 'error' | 'info' = 'info') {
    this.notification.set({ message, type });
    setTimeout(() => this.notification.set(null), 5000);
  }

  showConfirm(title: string, message: string, onConfirm: () => void) {
    this.confirmModal.set({ title, message, onConfirm });
  }

  cancelAdd() {
    this.isAdding.set(false);
    this.smtpForm.reset({ port: 587, isActive: true, rotationOrder: 0 });
  }

  async saveServer() {
    if (this.smtpForm.valid) {
      await this.firestore.addSmtpServer(this.smtpForm.value);
      this.showNotification('SMTP server added.', 'success');
      this.cancelAdd();
    }
  }

  async deleteServer(id: string) {
    this.showConfirm(
      'Delete SMTP Server',
      'Are you sure you want to delete this SMTP server?',
      async () => {
        await this.firestore.deleteSmtpServer(id);
        this.showNotification('SMTP server deleted.', 'info');
      }
    );
  }
}
