import {ChangeDetectionStrategy, Component, inject, effect, signal} from '@angular/core';
import {RouterOutlet, Router, RouterLink, RouterLinkActive} from '@angular/router';
import {AuthService} from './auth.service';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  auth = inject(AuthService);
  router = inject(Router);
  isSidebarOpen = signal(false);

  constructor() {
    effect(() => {
      if (this.auth.isReady()) {
        if (this.auth.user()) {
          if (this.router.url === '/login') {
            this.router.navigate(['/dashboard']);
          }
        } else {
          this.router.navigate(['/login']);
        }
      }
    });

    // Close sidebar on route change
    this.router.events.subscribe(() => {
      this.isSidebarOpen.set(false);
    });
  }

  toggleSidebar() {
    this.isSidebarOpen.update((v: boolean) => !v);
  }
}
