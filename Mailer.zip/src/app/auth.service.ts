import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  user = signal<{ uid: string; email: string; photoURL?: string; displayName?: string } | null>(null);
  isReady = signal<boolean>(false);

  constructor() {
    if (typeof localStorage !== 'undefined') {
      const savedUser = localStorage.getItem('hardcoded_user');
      if (savedUser) {
        this.user.set(JSON.parse(savedUser));
      }
    }
    this.isReady.set(true);
  }

  async loginWithHardcoded(username: string, password: string) {
    if (username === 'Mailsending2010.@-' && password === 'ZenixMart2010.@-') {
      const fakeUser = { uid: 'admin', email: 'admin@pixels.com' };
      this.user.set(fakeUser);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('hardcoded_user', JSON.stringify(fakeUser));
      }
    } else {
      throw new Error('Invalid username or password');
    }
  }

  async logout() {
    this.user.set(null);
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem('hardcoded_user');
    }
  }
}
