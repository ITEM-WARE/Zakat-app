import { Injectable } from '@angular/core';
import { db, auth } from '../firebase';
import { collection, doc, updateDoc, deleteDoc, onSnapshot, addDoc } from 'firebase/firestore';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: unknown;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

@Injectable({
  providedIn: 'root'
})
export class FirestoreService {
  // Smtp Servers
  getSmtpServers(callback: (data: unknown[]) => void) {
    const q = collection(db, 'smtp_servers');
    return onSnapshot(q, (snapshot) => {
      callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'smtp_servers'));
  }

  async addSmtpServer(data: Record<string, unknown>) {
    try {
      await addDoc(collection(db, 'smtp_servers'), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'smtp_servers');
    }
  }

  async updateSmtpServer(id: string, data: Record<string, unknown>) {
    try {
      await updateDoc(doc(db, 'smtp_servers', id), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `smtp_servers/${id}`);
    }
  }

  async deleteSmtpServer(id: string) {
    try {
      await deleteDoc(doc(db, 'smtp_servers', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `smtp_servers/${id}`);
    }
  }

  // Templates
  getTemplates(callback: (data: unknown[]) => void) {
    const q = collection(db, 'templates');
    return onSnapshot(q, (snapshot) => {
      callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'templates'));
  }

  async addTemplate(data: Record<string, unknown>) {
    try {
      await addDoc(collection(db, 'templates'), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'templates');
    }
  }

  async updateTemplate(id: string, data: Record<string, unknown>) {
    try {
      await updateDoc(doc(db, 'templates', id), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `templates/${id}`);
    }
  }

  async deleteTemplate(id: string) {
    try {
      await deleteDoc(doc(db, 'templates', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `templates/${id}`);
    }
  }

  // Recipients
  getRecipients(callback: (data: unknown[]) => void, errorCallback?: (error: unknown) => void) {
    const q = collection(db, 'recipients');
    return onSnapshot(q, (snapshot) => {
      callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      if (errorCallback) {
        errorCallback(error);
      } else {
        handleFirestoreError(error, OperationType.LIST, 'recipients');
      }
    });
  }

  async addRecipient(data: Record<string, unknown>) {
    try {
      await addDoc(collection(db, 'recipients'), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'recipients');
    }
  }

  async updateRecipient(id: string, data: Record<string, unknown>) {
    try {
      await updateDoc(doc(db, 'recipients', id), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `recipients/${id}`);
    }
  }

  async deleteRecipient(id: string) {
    try {
      await deleteDoc(doc(db, 'recipients', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `recipients/${id}`);
    }
  }
}
