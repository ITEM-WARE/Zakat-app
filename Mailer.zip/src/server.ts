import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import nodemailer from 'nodemailer';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '50mb' }));

const angularApp = new AngularNodeAppEngine();

app.post('/api/send-email', async (req, res) => {
  try {
    const { to, subject, html, smtpConfig } = req.body;

    if (!to || !subject || !html || !smtpConfig) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    if (smtpConfig.host === 'resend.com') {
      const resendResponse = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${smtpConfig.authPass}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: smtpConfig.authUser,
          to: to,
          subject: subject,
          html: html
        })
      });

      const info = await resendResponse.json();
      if (!resendResponse.ok) {
        throw new Error((info as { message?: string }).message || 'Resend API Error');
      }
      res.json({ success: true, messageId: (info as { id: string }).id });
      return;
    }

    const transporter = nodemailer.createTransport({
      host: smtpConfig.host,
      port: smtpConfig.port,
      secure: smtpConfig.port === 465, // true for 465, false for other ports (like 587)
      auth: {
        user: smtpConfig.authUser,
        pass: smtpConfig.authPass,
      },
    });

    const info = await transporter.sendMail({
      from: smtpConfig.authUser,
      to,
      subject,
      html,
    });

    res.json({ success: true, messageId: info.messageId });
  } catch (error: unknown) {
    console.error('Error sending email:', error);
    const errorMessage = error instanceof Error ? error.message : 'Failed to send email';
    res.status(500).json({ error: errorMessage });
  }
});

/**
 * Example Express Rest API endpoints can be defined here.
 * Uncomment and define endpoints as necessary.
 *
 * Example:
 * ```ts
 * app.get('/api/{*splat}', (req, res) => {
 *   // Handle API request
 * });
 * ```
 */

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
